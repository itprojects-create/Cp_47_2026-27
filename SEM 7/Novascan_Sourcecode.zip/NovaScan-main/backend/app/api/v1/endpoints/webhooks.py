from fastapi import APIRouter, Request, BackgroundTasks
import json
import os
import logging
import httpx
import re
import hmac
import hashlib
from typing import Optional
from datetime import datetime
from dotenv import load_dotenv
from bson import ObjectId

from app.services.intelligence.llm_engine import analyze_code
from app.services.delivery.notion_bot import notion_bot
from app.core.database import get_database 
from app.services.delivery.email_service import send_manager_to_employee_alert
from app.core.config import settings
from app.core.crypto import decrypt_key
from app.services.integration.oauth_token_manager import oauth_token_manager
from app.services.integration.github_app import github_app_configured
from slack_sdk import WebClient

# Load Environment Variables
load_dotenv()

# Configure Logging
logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

router = APIRouter()

# --- HELPER: GET CREDENTIALS (PROJECT-AWARE) ---
async def get_org_credentials(org_id: str, repo_full_name: str = None, project_id: str = None, include_github_token: bool = True):
    """Fetch integration secrets from the matching project only; never org-wide."""
    try:
        db = get_database()
        project = None
        if project_id:
            project_id_values = [str(project_id)]
            if ObjectId.is_valid(str(project_id)):
                project_id_values.append(ObjectId(str(project_id)))
            org_id_values = [str(org_id)]
            if ObjectId.is_valid(str(org_id)):
                org_id_values.append(ObjectId(str(org_id)))
            query = {
                "_id": {"$in": project_id_values},
                "organization_id": {"$in": org_id_values},
            }
            project = await db["projects"].find_one(query)
        elif repo_full_name:
            owner, _, repo_name = repo_full_name.partition("/")
            org_id_values = [str(org_id)]
            if ObjectId.is_valid(str(org_id)):
                org_id_values.append(ObjectId(str(org_id)))
            project = await db["projects"].find_one({
                "organization_id": {"$in": org_id_values},
                "repo_owner": {"$regex": f"^{re.escape(owner)}$", "$options": "i"},
                "repo_name": {"$regex": f"^{re.escape(repo_name)}$", "$options": "i"},
            })

        if not project:
            logger.warning(
                "No project found for integration event (org_id=%s, project_id=%s, repo=%s)",
                org_id,
                project_id,
                repo_full_name,
            )
            return None
        if repo_full_name:
            expected_repo = f"{project.get('repo_owner', '')}/{project.get('repo_name', '')}"
            if expected_repo.casefold() != repo_full_name.casefold():
                logger.warning("Ignoring repo event that does not match project '%s'", project.get("name"))
                return None

        settings_data = project.get("settings", {})
        oauth_credentials = await oauth_token_manager.credentials_for_project(
            org_id, str(project["_id"]), include_github=include_github_token
        )
        # GitHub API access must come from the repo-scoped GitHub App token.
        github_token = oauth_credentials.get("github_token")
        return {
            "project_id": str(project["_id"]),
            "github_token": github_token,
            "slack_token": oauth_credentials.get("slack_token") or settings_data.get("slack_bot_token"),
            "slack_channel": oauth_credentials.get("slack_channel") or settings_data.get("slack_channel"),
            "slack_incoming_webhook_url": oauth_credentials.get("slack_incoming_webhook_url"),
            "jira_url": oauth_credentials.get("jira_url") or settings_data.get("jira_url"),
            "jira_cloud_id": oauth_credentials.get("jira_cloud_id"),
            "jira_oauth_token": oauth_credentials.get("jira_oauth_token"),
            "jira_project_key": settings_data.get("jira_project_key", "SCRUM"),
            "jira_email": settings_data.get("jira_email"),
            "jira_token": settings_data.get("jira_api_token"),
            "jira_project_key": settings_data.get("jira_project_key", "SCRUM"),
            "notion_token": oauth_credentials.get("notion_token") or settings_data.get("notion_token"),
            "notion_database_id": oauth_credentials.get("notion_database_id") if oauth_credentials.get("notion_oauth_connected") else settings_data.get("notion_database_id"),
            "notion_parent_page_id": oauth_credentials.get("notion_parent_page_id") or settings_data.get("notion_parent_page_id"),
            "notion_parent_page_name": oauth_credentials.get("notion_parent_page_name"),
            "notion_parent_page_url": oauth_credentials.get("notion_parent_page_url")
        }
    except Exception as e:
        logger.error(f"❌ Error fetching credentials: {e}")
        return None

# --- HELPER: SAVE SCAN TO DB (FIXED) ---
async def save_scan_to_db(org_id, repo, pr_id, risk_data, pr_url, pr_title="Untitled", pr_author="Unknown", project_id=None):
    try:
        db = get_database()
        collection = db.get_collection("scans")
        scan_record = {
            "org_id": str(org_id),
            "project_id": str(project_id) if project_id else None,
            "repo": repo,
            "pr_id": pr_id,
            "pr_title": pr_title,     
            "author": pr_author,      
            "risk_score": risk_data.get("risk_score"),
            "analysis_status": risk_data.get("analysis_status", "complete"),
            "is_risky": risk_data.get("is_risky", False),
            "summary": risk_data.get("reason", "No summary"),
            "timestamp": datetime.utcnow(),
            "pr_url": pr_url
        }
        result = await collection.insert_one(scan_record)
        logger.info("Scan saved: %s by %s", pr_title, pr_author)
        return result.inserted_id
    except Exception as e:
        logger.error(f"❌ DB Save Error: {e}")

async def _fetch_pull_request_diff(token: str, repo_full_name: str, pr_number: int, diff_url: Optional[str]) -> str:
    """Fetch a PR diff, falling back to GitHub's pull-files API when needed."""
    headers = {
        "Authorization": f"Bearer {token}",
        "Accept": "application/vnd.github.v3.diff",
        "X-GitHub-Api-Version": "2022-11-28",
    }
    async with httpx.AsyncClient(timeout=30.0, follow_redirects=True) as client:
        if diff_url:
            response = await client.get(diff_url, headers=headers)
            if response.status_code == 200 and response.text.strip():
                return response.text
            logger.warning("GitHub PR diff URL returned %s for %s#%s", response.status_code, repo_full_name, pr_number)

        response = await client.get(
            f"https://api.github.com/repos/{repo_full_name}/pulls/{pr_number}/files",
            headers={**headers, "Accept": "application/vnd.github+json"},
            params={"per_page": 100},
        )
        if response.status_code != 200:
            logger.error("GitHub PR files API returned %s for %s#%s: %s", response.status_code, repo_full_name, pr_number, response.text[:300])
            return ""
        patches = []
        for item in response.json():
            patch = item.get("patch")
            if patch:
                patches.append(f"### {item.get('filename', 'changed file')}\n{patch}")
        return "\n\n".join(patches)


def _diff_unavailable_result() -> dict:
    return {
        "analysis_status": "failed",
        "risk_score": None,
        "reason": "NovaScan could not retrieve this pull request's code changes, so no risk score was produced. Check GitHub App pull request read access and retry with a new commit.",
        "is_risky": False,
    }


async def _organization_ai_config(org_id: str) -> tuple[Optional[str], str]:
    """Load and decrypt the organization's saved BYOK key for PR analysis."""
    db = get_database()
    if db is None:
        return None, "gemini"
    org_id_values = [str(org_id)]
    if ObjectId.is_valid(str(org_id)):
        org_id_values.append(ObjectId(str(org_id)))
    organization = await db["organizations"].find_one(
        {"_id": {"$in": org_id_values}}, {"ai_settings": 1}
    )
    ai_settings = (organization or {}).get("ai_settings") or {}
    encrypted_key = ai_settings.get("encrypted_api_key")
    try:
        api_key = decrypt_key(encrypted_key) if encrypted_key else None
    except Exception:
        logger.exception("Unable to decrypt the organization's configured AI key")
        api_key = None
    return api_key, ai_settings.get("provider") or "gemini"


# Register the static GitHub App route before the legacy /github/{org_id}
# route below. Otherwise, the path segment "app" is consumed as org_id.
@router.post("/github/app")
async def handle_github_app_webhook(request: Request):
    """Verify and route GitHub App events to the exact linked project repository."""
    webhook_secret = getattr(settings, "GITHUB_WEBHOOK_SECRET", None)
    if not (webhook_secret and github_app_configured()):
        return {"status": "disabled"}
    body = await request.body()
    signature = request.headers.get("X-Hub-Signature-256", "")
    expected = "sha256=" + hmac.new(webhook_secret.encode(), body, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(signature, expected):
        from fastapi import HTTPException
        raise HTTPException(status_code=401, detail="Invalid GitHub webhook signature")
    if request.headers.get("X-GitHub-Event") != "pull_request":
        return {"status": "ignored"}
    payload = json.loads(body)
    installation_id = str((payload.get("installation") or {}).get("id") or "")
    repo = payload.get("repository") or {}
    repo_name, repo_id = repo.get("full_name") or "", str(repo.get("id") or "")
    if not (installation_id and repo_name and repo_id):
        return {"status": "skipped", "message": "Missing installation or repository identity"}
    db = get_database()
    if db is None:
        return {"status": "error", "message": "Database unavailable"}
    matches = await db["oauth_connections"].find({
        "provider": "github", "installation_id": installation_id, "repository_id": repo_id,
    }).to_list(100)
    for connection in matches:
        if (connection.get("repository_full_name") or "").casefold() == repo_name.casefold():
            return await _process_github_app_event(
                str(connection["org_id"]), str(connection["project_id"]), payload
            )
    return {"status": "ignored", "message": "Repository is not linked to a NovaScan project"}


# --- WEBHOOK HANDLER ---
@router.post("/github/{org_id}")
@router.post("/github/{org_id}/{project_id}")
async def handle_github_webhook(org_id: str, request: Request, project_id: Optional[str] = None):
    try:
        body_content = await request.body()
        if not body_content:
            return {"status": "skipped", "message": "Empty body"}
        
        payload = await request.json()
        event_type = request.headers.get("X-GitHub-Event")

        if event_type == "pull_request" and payload.get("action") in ["opened", "synchronize", "reopened"]:
            
            # Extract PR Details
            pr = payload.get("pull_request")
            pr_number = pr.get("number")
            repo_full_name = payload.get("repository", {}).get("full_name") # "Owner/Repo"
            title = pr.get("title", "Untitled")
            user_login = pr.get("user", {}).get("login", "Unknown") 
            body = pr.get("body", "") or ""
            diff_url = pr.get("diff_url")
            pr_url = pr.get("html_url")

            logger.info(f"✅ Processing PR #{pr_number} ({repo_full_name}) for Org: {org_id}")

            # 1. Fetch Credentials (Passing Repo Name to find Project)
            creds = await get_org_credentials(org_id, repo_full_name, project_id)
            if not creds:
                logger.error("❌ No credentials found for this project.")
                return {"status": "error", "message": "Credentials not found."}

            # 2. Get Diff (With Fixed Headers)
            diff_text = ""
            if creds.get("github_token"):
                async with httpx.AsyncClient() as client:
                    headers = {
                        "Authorization": f"token {creds['github_token']}",
                        "Accept": "application/vnd.github.v3.diff" 
                    }
                    resp = await client.get(diff_url, headers=headers, follow_redirects=True)
                    if resp.status_code == 200:
                        diff_text = resp.text
                    else:
                        logger.error(f"❌ Failed to fetch diff: {resp.status_code}")

            # 3. AI Analysis
            ai_key, ai_provider = await _organization_ai_config(org_id)
            risk_analysis = await analyze_code(diff_text, {"title": title, "body": body}, custom_api_key=ai_key, provider=ai_provider) if diff_text.strip() else _diff_unavailable_result()
            
            # 4. Save to DB (Passing Title/Author)
            scan_id = await save_scan_to_db(
                org_id, repo_full_name, pr_number, risk_analysis, pr_url, 
                pr_title=title, 
                pr_author=user_login,
                project_id=creds.get("project_id"),
            )

            # 5. Trigger Dispatch
            event_data = {
                "summary": f"PR #{pr_number} in {repo_full_name}",
                "title": title,
                "url": pr_url,
                "repo": repo_full_name,
                "pr_id": pr_number,
                "author": user_login,
            }
            deliveries = await dispatch_notifications(creds, risk_analysis, event_data, org_id)
            if scan_id and deliveries:
                await get_database()["scans"].update_one({"_id": scan_id}, {"$set": {"deliveries": deliveries, "deliveries_updated_at": datetime.utcnow()}})

        return {"status": "processed"}

    except Exception as e:
        logger.error(f"❌ Error in webhook: {e}")
        return {"status": "error", "message": str(e)}

async def _process_github_app_event(org_id: str, project_id: str, payload: dict):
    if payload.get("action") not in ("opened", "synchronize", "reopened"):
        return {"status": "ignored"}
    pr = payload.get("pull_request") or {}
    repo_name = (payload.get("repository") or {}).get("full_name")
    if not (pr.get("number") and repo_name):
        return {"status": "skipped", "message": "Missing pull request or repository"}
    creds = await get_org_credentials(org_id, repo_name, project_id)
    if not creds or not creds.get("github_token"):
        return {"status": "error", "message": "Project/repository credentials could not be resolved for this installation"}
    diff_text = await _fetch_pull_request_diff(
        creds["github_token"], repo_name, pr["number"], pr.get("diff_url")
    )
    ai_key, ai_provider = await _organization_ai_config(org_id)
    risk = await analyze_code(diff_text, {"title": pr.get("title", "Untitled"), "body": pr.get("body") or ""}, custom_api_key=ai_key, provider=ai_provider) if diff_text.strip() else _diff_unavailable_result()
    author = (pr.get("user") or {}).get("login", "Unknown")
    scan_id = await save_scan_to_db(org_id, repo_name, pr["number"], risk, pr.get("html_url"), pr_title=pr.get("title", "Untitled"), pr_author=author, project_id=project_id)
    deliveries = await dispatch_notifications(creds, risk, {
        "summary": f"PR #{pr['number']} in {repo_name}", "title": pr.get("title", "Untitled"),
        "url": pr.get("html_url"), "repo": repo_name, "pr_id": pr["number"], "author": author,
    }, org_id)
    if scan_id and deliveries:
        await get_database()["scans"].update_one({"_id": scan_id}, {"$set": {"deliveries": deliveries, "deliveries_updated_at": datetime.utcnow()}})
    return {"status": "processed"}


def _slack_channel_url(channel_id: Optional[str]) -> Optional[str]:
    if channel_id and re.fullmatch(r"[CGD][A-Z0-9]+", channel_id.upper()):
        return f"https://app.slack.com/archives/{channel_id}"
    return None


async def dispatch_notifications(creds, risk_data, event_data, org_id: str, existing_delivery=None):
    """
    Handles alerts. Now uses the 'creds' dictionary which contains the correct tokens.
    """
    db = get_database()
    existing_delivery = existing_delivery or {}
    notion_url = (existing_delivery.get("notion") or {}).get("url")
    jira_url = (existing_delivery.get("jira") or {}).get("url")
    slack_url = (existing_delivery.get("slack") or {}).get("url")
    notion_done = (existing_delivery.get("notion") or {}).get("status") == "created"
    jira_done = (existing_delivery.get("jira") or {}).get("status") == "created"
    slack_done = (existing_delivery.get("slack") or {}).get("status") == "sent"
    notion_error = (existing_delivery.get("notion") or {}).get("error")
    slack_error = (existing_delivery.get("slack") or {}).get("error")
    if slack_done and not slack_url:
        slack_url = _slack_channel_url(creds.get("slack_channel"))

    # Lookup Org just for Manager Info (Tokens are already in 'creds')
    query = {"$or": [{"_id": org_id}, {"_id": ObjectId(org_id) if ObjectId.is_valid(org_id) else None}]}
    org = await db["organizations"].find_one(query)
    
    manager_name = "Project Manager"
    manager_email = settings.SMTP_USER # Default
    
    if org:
        manager = await db["users"].find_one({"_id": org.get("manager_id")})
        if manager:
            manager_name = manager.get("full_name", "Project Manager")
            manager_email = manager.get("email")

    risk_score = int(risk_data.get("risk_score", 0) or 0)

    # --- 1. Create a Notion audit report for medium or higher risk ---
    if risk_score >= 4 and not notion_done and not notion_url and creds.get("notion_token") and (creds.get("notion_parent_page_id") or creds.get("notion_database_id")):
        notion_res = await notion_bot.create_incident_report(
            analysis=risk_data,
            event_summary=event_data["summary"],
            pr_url=event_data["url"],
            notion_token=creds.get("notion_token"),
            database_id=creds.get("notion_database_id"),
            parent_page_id=creds.get("notion_parent_page_id"),
            report_context=event_data,
            database_status_type=creds.get("notion_database_status_type") or "status",
        )
        if notion_res and notion_res.get("url"):
            notion_url = notion_res.get("url")
            notion_done = True
            logger.info(f"📄 Notion report created: {notion_url}")
        elif notion_res and notion_res.get("error"):
            notion_error = notion_res["error"]
    elif risk_score >= 4:
        logger.info("ℹ️ Notion skipped (Tokens missing in Project settings)")

    # --- 2. Raise Slack and Jira alerts for medium/high scores ---
    
    if risk_score >= 4:
        # Slack
        if not slack_done and not slack_url and creds.get("slack_token") and creds.get("slack_channel"):
            slack_result = await send_slack_alert(creds, event_data["repo"], event_data["pr_id"], risk_data, notion_url, org_id)
            if isinstance(slack_result, dict):
                slack_url = slack_result.get("url")
                slack_done = slack_result.get("status") == "sent"
                slack_error = slack_result.get("error")
            else:
                slack_url = slack_result
                slack_done = bool(slack_url)
        
        # Jira
        if not jira_done and not jira_url and creds.get("jira_oauth_token") and creds.get("jira_cloud_id"):
            jira_url = await create_jira_ticket_oauth(creds, event_data["repo"], event_data["pr_id"], event_data["title"], risk_data, event_data["url"], notion_url)
            jira_done = bool(jira_url)
        elif not jira_done and not jira_url and creds.get("jira_url") and creds.get("jira_token"):
            jira_url = create_jira_ticket(creds, event_data["repo"], event_data["pr_id"], event_data["title"], risk_data, event_data["url"], notion_url)
            jira_done = bool(jira_url)

    # --- 3. High Risk Email ---
    if risk_score >= 6:
        # Simple lookup for now
        employees = [] # Add your employee lookup logic here if needed
        # await send_manager_to_employee_alert(...) 
        pass

    return {
        "notion": {"url": notion_url, "status": "created" if notion_done else ("failed" if notion_error else "unavailable"), "error": notion_error},
        "jira": {"url": jira_url, "status": "created" if jira_done else "unavailable"},
        "slack": {"url": slack_url, "status": "sent" if slack_done else ("failed" if slack_error else "unavailable"), "error": slack_error},
    }
        
async def send_slack_alert(creds, repo, pr_id, risk_data, notion_url, org_id):
    client = WebClient(token=creds["slack_token"])
    main_text = f"🚨 NovaScan Risk Alert: PR #{pr_id} in {repo}"

    blocks = [
        {"type": "header", "text": {"type": "plain_text", "text": "🚨 NovaScan Risk Alert"}},
        {"type": "section", "text": {"type": "mrkdwn", "text": f"*Repo:* {repo} | *PR:* #{pr_id}\n*Score:* {risk_data.get('risk_score')}/10\n*Reason:* {risk_data.get('reason')}"}}
    ]

    action_elements = []
    if notion_url:
        action_elements.append({"type": "button", "text": {"type": "plain_text", "text": "📄 View Notion Report"}, "url": notion_url, "style": "primary"})
    else:
        action_elements.append({"type": "button", "text": {"type": "plain_text", "text": "📝 Generate Report Manually"}, "style": "danger", "action_id": "trigger_notion_pm", "value": f"{org_id}|https://github.com/{repo}/pull/{pr_id}"})

    if action_elements:
        blocks.append({"type": "actions", "elements": action_elements})

    try:
        response = client.chat_postMessage(channel=creds["slack_channel"], text=main_text, blocks=blocks)
        permalink = None
        if response.get("channel") and response.get("ts"):
            try:
                permalink = client.chat_getPermalink(channel=response["channel"], message_ts=response["ts"]).get("permalink")
                return {"url": permalink, "status": "sent"}
            except Exception:
                logger.info("Slack message sent but permalink lookup failed")
                return {"url": None, "status": "sent"}
        logger.info("Slack alert sent")
        return {"url": None, "status": "sent"}
    except Exception as e:
        logger.error(f"❌ Slack Error: {e}")
        slack_response = getattr(e, "response", None)
        slack_api_error = slack_response.get("error") if hasattr(slack_response, "get") else None
        if slack_api_error == "not_in_channel" and creds.get("slack_incoming_webhook_url"):
            try:
                async with httpx.AsyncClient(timeout=15.0) as client:
                    webhook_response = await client.post(
                        creds["slack_incoming_webhook_url"],
                        json={"text": main_text, "blocks": blocks},
                    )
                if webhook_response.status_code == 200 and webhook_response.text.strip() == "ok":
                    logger.info("Slack alert delivered through the project's incoming webhook")
                    return {"url": _slack_channel_url(creds.get("slack_channel")), "status": "sent"}
                return {"url": None, "status": "failed", "error": f"Slack incoming webhook returned HTTP {webhook_response.status_code}"}
            except Exception as webhook_exc:
                logger.error("Slack incoming webhook fallback failed: %s", webhook_exc)
                return {"url": None, "status": "failed", "error": str(webhook_exc)[:300]}
        if slack_api_error == "not_in_channel":
            return {
                "url": None,
                "status": "failed",
                "error": "NovaScan bot is not in the configured Slack channel. Invite the NovaScan app to that channel, then retry delivery.",
            }
        return {"url": None, "status": "failed", "error": str(e)[:300]}

def create_jira_ticket(creds, repo, pr_id, pr_title, risk_data, pr_url, notion_url=None):
    try:
        from jira import JIRA
        jira = JIRA(server=creds["jira_url"], basic_auth=(creds["jira_email"], creds["jira_token"]))
        
        desc = f"Risk Score: {risk_data.get('risk_score')}/10\nReason: {risk_data.get('reason')}\nPR Link: {pr_url}"
        if notion_url:
            desc += f"\nDetailed Report: {notion_url}"

        issue_dict = {
            'project': {'key': creds["jira_project_key"]}, 
            'summary': f"[Risk Detected] PR #{pr_id}: {pr_title}",
            'description': desc,
            'issuetype': {'name': 'Task'},
        }
        issue = jira.create_issue(fields=issue_dict)
        logger.info("Jira ticket created: %s", issue.key)
        return f"{creds['jira_url'].rstrip('/')}/browse/{issue.key}"
    except Exception as e:
        logger.error(f"❌ Jira Error: {e}")


async def create_jira_ticket_oauth(creds, repo, pr_id, pr_title, risk_data, pr_url, notion_url=None):
    cloud_id = creds.get("jira_cloud_id")
    token = creds.get("jira_oauth_token")
    if not cloud_id or not token:
        return None
    description = f"Risk Score: {risk_data.get('risk_score')}/10\nReason: {risk_data.get('reason')}\nPR Link: {pr_url}"
    if notion_url:
        description += f"\nDetailed Report: {notion_url}"
    payload = {
        "fields": {
            "project": {"key": creds.get("jira_project_key", "KAN")},
            "summary": f"[Risk Detected] PR #{pr_id}: {pr_title}",
            "description": {
                "type": "doc",
                "version": 1,
                "content": [{"type": "paragraph", "content": [{"type": "text", "text": description}]}],
            },
            "issuetype": {"name": "Task"},
        }
    }
    endpoint = f"https://api.atlassian.com/ex/jira/{cloud_id}/rest/api/3/issue"
    try:
        async with httpx.AsyncClient(timeout=20) as client:
            response = await client.post(
                endpoint,
                json=payload,
                headers={
                    "Authorization": f"Bearer {token}",
                    "Accept": "application/json",
                    "Content-Type": "application/json",
                },
            )
        if response.status_code in (200, 201):
            logger.info("Jira issue created for project %s", creds.get("jira_project_key", "KAN"))
            issue_key = response.json().get("key")
            site_url = (creds.get("jira_url") or "").rstrip("/")
            return f"{site_url}/browse/{issue_key}" if site_url and issue_key else None
        else:
            logger.warning("Jira OAuth issue create failed (%s): %s", response.status_code, response.text[:300])
    except Exception as exc:
        logger.exception("Jira OAuth issue create failed: %s", exc)
    return None

# --- INTERACTIVE HANDLER ---
@router.post("/slack/actions")
async def handle_slack_interactive(request: Request, background_tasks: BackgroundTasks):
    try:
        form_data = await request.form()
        payload = json.loads(form_data["payload"])
        action = payload["actions"][0]
        
        if action["action_id"] == "trigger_notion_pm":
            raw_value = action["value"]
            if "|" not in raw_value: return {"status": "error"}
            org_id, pr_url = raw_value.split("|", 1)
            
            # Use REPO NAME from URL to find credentials
            repo_name_from_url = pr_url.split("github.com/")[1].split("/pull")[0]
            creds = await get_org_credentials(org_id, repo_name_from_url)
            
            if not creds: return {"status": "error"}

            background_tasks.add_task(
                notion_bot.create_incident_report,
                analysis={"reason": f"Manual Trigger by {payload['user']['username']}", "risk_score": 8},
                event_summary="Developer Initiated Report",
                pr_url=pr_url,
                notion_token=creds.get("notion_token"),
                database_id=creds.get("notion_database_id")
            )
            return {"status": "ok"}
    except Exception as e:
        logger.error(f"❌ Error handling Slack interaction: {e}")
        return {"status": "error"}
    return {"status": "ok"}
