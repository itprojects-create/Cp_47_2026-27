// app/projects/[id]/page.tsx
'use client';

import { useEffect, useState } from 'react';
import { useParams, useSearchParams } from 'next/navigation';
import Link from 'next/link';
import api, { getUserFromToken } from '@/lib/api';
import {
  ArrowLeft,
  GitPullRequest,
  ShieldAlert,
  CheckCircle,
  AlertTriangle,
  Clock,
  Github,
  Activity,
  Slack,
  Trello,
  CheckCircle2,
  Loader2,
  PlugZap,
  Unplug,
  Settings,
  FileText
} from 'lucide-react';

type OAuthProvider = 'github' | 'slack' | 'jira' | 'notion';
type ProjectIntegrationStatus = {
  configured?: Partial<Record<OAuthProvider, boolean>>;
  connections?: Partial<Record<OAuthProvider, { status?: string; live?: boolean; workspace_name?: string; scope?: string; connected_at?: string; details?: { repository?: string; database_name?: string; database_url?: string; parent_page_url?: string } }>>;
};

const integrationProviders: { id: OAuthProvider; name: string; icon: any }[] = [
  { id: 'github', name: 'GitHub', icon: Github },
  { id: 'slack', name: 'Slack', icon: Slack },
  { id: 'jira', name: 'Jira', icon: Trello },
  { id: 'notion', name: 'Notion Audit Reports', icon: FileText },
];

export default function ProjectDashboard() {
  const params = useParams();
  const searchParams = useSearchParams();
  const projectId = String(params.id || '');

  const [project, setProject] = useState<any>(null);
  const [scans, setScans] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [integrationStatus, setIntegrationStatus] = useState<ProjectIntegrationStatus>({});
  const [integrationsLoading, setIntegrationsLoading] = useState(true);
  const [activeIntegration, setActiveIntegration] = useState<OAuthProvider | null>(null);
  const [integrationError, setIntegrationError] = useState('');
  const [canManageIntegrations, setCanManageIntegrations] = useState(false);

  useEffect(() => {
    const role = String(getUserFromToken()?.role || '').toLowerCase();
    setCanManageIntegrations(['admin', 'hr', 'manager'].includes(role));
    const fetchData = async () => {
      try {
        // 1. Get Project Details
        const projRes = await api.get(`/projects/${projectId}`);
        const projectData = projRes.data;
        setProject(projectData);

        // 2. Get Risk Scans (Fetch ALL for org, then filter client-side by Repo Name)
        // This is a temporary fix as Risks in DB missing 'project_id'
        const scansRes = await api.get(`/risks?limit=100`);

        const repoPath = `${projectData.repo_owner}/${projectData.repo_name}`;
        const filteredScans = scansRes.data.filter((scan: any) => scan.repo === repoPath);

        setScans(filteredScans);
      } catch (err) {
        console.error("Failed to fetch project data", err);
      } finally {
        setLoading(false);
      }
    };

    if (projectId) fetchData();
  }, [projectId]);

  const fetchIntegrationStatus = async () => {
    if (!projectId) return;
    setIntegrationsLoading(true);
    try {
      const { data } = await api.get('/oauth/status', { params: { project_id: projectId, live: true } });
      setIntegrationStatus(data);
      setIntegrationError('');
    } catch (err: any) {
      setIntegrationError(err.response?.data?.detail || 'Could not load this project’s tool connections.');
    } finally {
      setIntegrationsLoading(false);
    }
  };

  useEffect(() => {
    fetchIntegrationStatus();
  }, [projectId]);

  useEffect(() => {
    if (loading || searchParams.get('status') !== 'success') return;
    document.getElementById('project-integrations')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }, [loading, searchParams]);

  const connectIntegration = async (provider: OAuthProvider) => {
    setActiveIntegration(provider);
    setIntegrationError('');
    try {
      const { data } = await api.get(`/oauth/${provider}/authorize`, {
        params: { project_id: projectId, return_to: 'project' },
      });
      if (!data.auth_url) throw new Error('The server did not return an authorization URL.');
      window.location.assign(data.auth_url);
    } catch (err: any) {
      setIntegrationError(err.response?.data?.detail || err.message || `Could not connect ${provider}.`);
      setActiveIntegration(null);
    }
  };

  const disconnectIntegration = async (provider: OAuthProvider) => {
    setActiveIntegration(provider);
    setIntegrationError('');
    try {
      await api.delete(`/oauth/${provider}`, { params: { project_id: projectId } });
      await fetchIntegrationStatus();
    } catch (err: any) {
      setIntegrationError(err.response?.data?.detail || `Could not disconnect ${provider}.`);
    } finally {
      setActiveIntegration(null);
    }
  };

  if (loading) return <div className="p-12 text-center text-gray-500">Loading Intelligence Feed...</div>;
  if (!project) return <div className="p-12 text-center">Project not found</div>;

  return (
    <div className="min-h-screen bg-background p-6 md:p-10 text-foreground">

      {/* === TOP NAVIGATION === */}
      <div className="max-w-6xl mx-auto mb-8">
        <Link
          href="/dashboard"
          className="inline-flex items-center text-sm text-muted-foreground hover:text-foreground mb-4 transition-colors"
        >
          <ArrowLeft className="h-4 w-4 mr-1" /> Back to Organization
        </Link>

        <div className="flex justify-between items-start">
          <div>
            <h1 className="text-3xl font-bold text-foreground flex items-center gap-3">
              {project.name}
              <span className="px-3 py-1 bg-emerald-500/10 text-emerald-600 dark:text-emerald-400 text-xs font-bold rounded-full border border-emerald-500/20">
                LIVE
              </span>
            </h1>
            <a
              href={`https://github.com/${project.repo_owner}/${project.repo_name}`}
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-2 text-muted-foreground mt-2 hover:text-primary transition-colors"
            >
              <Github className="h-4 w-4" />
              <span className="font-mono">{project.repo_owner}/{project.repo_name}</span>
            </a>
          </div>

          <div className="flex gap-2">
            <Link href={`/projects/${encodeURIComponent(projectId)}/settings`} className="inline-flex items-center gap-2 rounded-lg border border-border bg-card px-4 py-2 text-sm font-medium text-foreground transition-colors hover:bg-muted/50"><Settings className="h-4 w-4" /> Settings</Link>
            <a href="#project-integrations" className="px-4 py-2 bg-card border border-border rounded-lg text-sm font-medium text-foreground hover:bg-muted/50 transition-colors">Project tools</a>
          </div>
        </div>
      </div>

      {(searchParams.get('status') || searchParams.get('message')) && (
        <div className={`max-w-6xl mx-auto mb-6 rounded-lg border p-4 text-sm ${searchParams.get('status') === 'success' ? 'border-emerald-500/30 bg-emerald-500/5 text-emerald-700 dark:text-emerald-300' : searchParams.get('status') === 'pending' ? 'border-amber-500/30 bg-amber-500/5 text-amber-700 dark:text-amber-300' : 'border-destructive/30 bg-destructive/5 text-destructive'}`} role="status">
          {searchParams.get('message') || `OAuth ${searchParams.get('status')}`}
        </div>
      )}

      {/* === STATS OVERVIEW === */}
      <div className="max-w-6xl mx-auto grid grid-cols-1 md:grid-cols-3 gap-4 mb-10">
        <div className="bg-card p-5 rounded-xl border border-border shadow-sm">
          <p className="text-sm font-medium text-muted-foreground mb-1">Total Scans</p>
          <p className="text-2xl font-bold text-foreground">{scans.length}</p>
        </div>
        <div className="bg-card p-5 rounded-xl border border-border shadow-sm">
          <p className="text-sm font-medium text-muted-foreground mb-1">High Risks Detected</p>
          <p className="text-2xl font-bold text-red-600 dark:text-red-500">
            {scans.filter(s => s.risk_score > 7).length}
          </p>
        </div>
        <div className="bg-card p-5 rounded-xl border border-border shadow-sm">
          <p className="text-sm font-medium text-muted-foreground mb-1">Avg Risk Score</p>
          <p className="text-2xl font-bold text-blue-600 dark:text-blue-400">
            {scans.some(s => s.risk_score != null)
              ? (scans.filter(s => s.risk_score != null).reduce((acc, curr) => acc + curr.risk_score, 0) / scans.filter(s => s.risk_score != null).length).toFixed(1)
              : '—'}
          </p>
        </div>
      </div>

      <section id="project-integrations" className="max-w-6xl mx-auto mb-10 scroll-mt-8">
        <div className="mb-5 flex flex-col gap-2 sm:flex-row sm:items-end sm:justify-between">
          <div>
            <h2 className="text-xl font-bold text-foreground flex items-center gap-2"><PlugZap className="h-5 w-5 text-primary" />Project tools</h2>
            <p className="mt-1 text-sm text-muted-foreground">These connections belong only to {project.name}; other projects in your organization have separate connections.</p>
          </div>
          <button type="button" onClick={fetchIntegrationStatus} disabled={integrationsLoading} className="self-start rounded-md border border-border px-3 py-2 text-sm font-medium hover:bg-muted/50 disabled:opacity-60 sm:self-auto">
            {integrationsLoading ? 'Refreshing…' : 'Refresh status'}
          </button>
        </div>
        {integrationError && <p role="alert" className="mb-4 rounded-lg border border-destructive/30 bg-destructive/5 p-3 text-sm text-destructive">{integrationError}</p>}
        <div className="grid gap-4 md:grid-cols-2 xl:grid-cols-4">
          {integrationProviders.map(({ id, name, icon: Icon }) => {
            const connection = integrationStatus.connections?.[id];
            const connected = connection?.status === 'connected';
            const configured = integrationStatus.configured?.[id] !== false;
            const busy = activeIntegration === id;
            return (
              <article key={id} className="rounded-xl border border-border bg-card p-5 shadow-sm">
                <div className="flex items-start justify-between gap-3">
                  <div className="flex items-center gap-3">
                    <div className="flex h-10 w-10 items-center justify-center rounded-lg bg-muted"><Icon className="h-5 w-5" /></div>
                  <div><h3 className="font-semibold">{name}</h3><p className="mt-0.5 text-xs text-muted-foreground">{integrationsLoading ? 'Checking connection…' : connected ? `${id === 'github' ? connection?.details?.repository || connection?.workspace_name || 'Connected' : id === 'notion' ? connection?.details?.database_name || `${connection?.workspace_name || 'Connected'} · tracker setup needed in settings` : connection?.workspace_name || 'Connected'}${connection?.live === false ? ' · live check needs attention' : ''}` : connection?.status === 'expired' ? 'Reconnect required' : 'Not connected'}</p></div>
                  </div>
                  {connected && <CheckCircle2 className="h-5 w-5 shrink-0 text-emerald-500" />}
                </div>
                <div className="mt-5 flex gap-2">
                  {connected ? (
                    <>
                      {id === 'notion' && (connection?.details?.parent_page_url || connection?.details?.database_url) && <a href={connection?.details?.parent_page_url || connection?.details?.database_url} target="_blank" rel="noopener noreferrer" className="inline-flex items-center rounded-md border border-border px-3 py-2 text-sm font-medium hover:bg-muted/50">Open tracker page</a>}
                      {canManageIntegrations && <button type="button" onClick={() => disconnectIntegration(id)} disabled={busy} className="inline-flex items-center gap-2 rounded-md border border-border px-3 py-2 text-sm font-medium hover:bg-muted/50 disabled:opacity-60">
                        {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <Unplug className="h-4 w-4" />} Disconnect
                      </button>}
                    </>
                  ) : (
                    canManageIntegrations ? <button type="button" onClick={() => connectIntegration(id)} disabled={busy || integrationsLoading || !configured} className="inline-flex items-center gap-2 rounded-md bg-primary px-3 py-2 text-sm font-semibold text-primary-foreground hover:bg-primary/90 disabled:cursor-not-allowed disabled:opacity-50">
                      {busy ? <Loader2 className="h-4 w-4 animate-spin" /> : <PlugZap className="h-4 w-4" />}{configured ? `Connect ${name}` : 'OAuth not configured'}
                    </button> : <p className="text-sm text-muted-foreground">Ask a project manager or admin to connect this tool.</p>
                  )}
                </div>
              </article>
            );
          })}
        </div>
      </section>

      {/* === THE FEED === */}
      <div className="max-w-6xl mx-auto">
        <h2 className="text-xl font-bold text-foreground mb-6 flex items-center gap-2">
          <Activity className="h-5 w-5 text-blue-600 dark:text-blue-400" />
          Intelligence Feed
        </h2>

        {scans.length === 0 ? (
          <div className="bg-card rounded-xl border border-dashed border-border p-12 text-center">
            <div className="bg-blue-500/10 h-16 w-16 rounded-full flex items-center justify-center mx-auto mb-4">
              <GitPullRequest className="h-8 w-8 text-blue-500" />
            </div>
            <h3 className="text-lg font-bold text-foreground">Waiting for Data...</h3>
            <p className="text-muted-foreground max-w-md mx-auto mt-2">
              NovaScan is listening. Create a Pull Request in your repo to trigger the first AI analysis.
            </p>
          </div>
        ) : (
          <div className="space-y-4">
            {scans.map((scan) => (
              <ScanCard key={scan._id || scan.id} scan={scan} />
            ))}
          </div>
        )}
      </div>
    </div>
  );
}

// === SUB-COMPONENT: Scan Card ===
function ScanCard({ scan }: any) {
  // Determine color based on Risk Score (0-10)
  const hasScore = scan.risk_score != null;
  const isHighRisk = hasScore && scan.risk_score >= 7;
  const isMediumRisk = hasScore && scan.risk_score >= 4 && scan.risk_score < 7;

  let borderColor = "border-border";
  let badgeColor = hasScore ? "bg-emerald-500/10 text-emerald-600 dark:text-emerald-400" : "bg-muted text-muted-foreground";
  let icon = hasScore ? <CheckCircle className="h-5 w-5 text-emerald-500" /> : <AlertTriangle className="h-5 w-5 text-muted-foreground" />;

  if (isHighRisk) {
    borderColor = "border-red-500/30 bg-red-500/5";
    badgeColor = "bg-red-500/10 text-red-600 dark:text-red-400";
    icon = <ShieldAlert className="h-5 w-5 text-red-500" />;
  } else if (isMediumRisk) {
    borderColor = "border-yellow-500/30 bg-yellow-500/5";
    badgeColor = "bg-yellow-500/10 text-yellow-600 dark:text-yellow-400";
    icon = <AlertTriangle className="h-5 w-5 text-yellow-500" />;
  }

  return (
    <div className={`bg-card rounded-xl border ${borderColor} p-6 shadow-sm transition-all hover:shadow-md`}>
      <div className="flex justify-between items-start mb-4">
        <div className="flex items-start gap-4">
          <div className="mt-1">{icon}</div>
          <div>
            {/* 🔴 MAPPED to Backend: pr_id instead of pr_number */}
            <h3 className="text-lg font-bold text-foreground">
              PR #{scan.pr_id}: {scan.pr_title || "Pull Request Analysis"}
            </h3>
            <div className="flex items-center gap-3 text-sm text-muted-foreground mt-1">
              <span className="flex items-center gap-1">
                <Clock className="h-3 w-3" />
                {/* 🔴 MAPPED to Backend: timestamp instead of created_at */}
                {scan.timestamp ? new Date(scan.timestamp).toLocaleDateString() : "Just now"}
              </span>
              <span>•</span>
              <span className="font-mono">{scan.author || "GitHub User"}</span>
            </div>
          </div>
        </div>

        <div className={`px-4 py-2 rounded-lg text-center ${badgeColor}`}>
          <p className="text-xs font-bold uppercase tracking-wider">Risk Score</p>
          <p className="text-sm font-bold">{hasScore ? scan.risk_score : "Unavailable"}</p>
        </div>
      </div>

      <div className="bg-muted/50 rounded-lg p-4 text-sm text-foreground/80 leading-relaxed border border-border">
        <p className="font-medium mb-1 text-foreground">AI Assessment:</p>
        {/* 🔴 MAPPED to Backend: summary instead of ai_summary */}
        {scan.summary || "Analysis pending..."}
      </div>

      {/* Link to PR if available */}
      {scan.pr_url && (
        <div className="mt-4">
          <a href={scan.pr_url} target="_blank" rel="noreferrer" className="text-primary hover:underline text-sm font-semibold">
            View Pull Request &rarr;
          </a>
        </div>
      )}
      <div className="mt-4 flex flex-wrap gap-2">
        <DeliveryLink label="Notion Audit Report" delivery={scan.deliveries?.notion} />
        <DeliveryLink label="Jira Ticket" delivery={scan.deliveries?.jira} />
        <DeliveryLink label="Slack Message" delivery={scan.deliveries?.slack} />
      </div>
    </div>
  );
}

function DeliveryLink({ label, delivery }: { label: string; delivery?: { url?: string; status?: string; error?: string } }) {
  const available = !!delivery?.url;
  return available ? (
    <a href={delivery!.url} target="_blank" rel="noreferrer" className="inline-flex items-center rounded-md border border-border px-3 py-2 text-xs font-semibold text-foreground hover:bg-muted">
      View {label} ↗
    </a>
  ) : (
    <span title={delivery?.error || (delivery?.status === "unavailable" ? "No successful delivery link is stored; verify this project's integration settings." : "This artifact has not been created yet.")} className="inline-flex items-center rounded-md border border-dashed border-border px-3 py-2 text-xs text-muted-foreground">
      {label}: {delivery?.status === "sent" || delivery?.status === "created" ? "Sent" : delivery?.status === "failed" ? "Failed" : "Not available"}
    </span>
  );
}
